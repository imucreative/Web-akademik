<div class="col-md-12">
	<!-- start: DYNAMIC TABLE PANEL -->
	<div class="panel panel-default">
		<div class="panel-heading">
			<i class="fa fa-bullhorn"></i> Gagal Mengakses Modul
			<div class="panel-tools"></div>
		</div>
		<div class="panel-body">
            
			<div class="alert alert-danger">
				<i class="fa fa-times-circle"></i> <strong><?php echo $gagal_akses_modul;?></strong>
			</div>
		</div>
	</div>
	<!-- end: DYNAMIC TABLE PANEL -->
</div>